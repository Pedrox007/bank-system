from django.contrib import admin

from core.models import Account


admin.site.register(Account)
